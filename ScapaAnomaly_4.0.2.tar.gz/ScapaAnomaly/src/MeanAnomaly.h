#ifndef ___MEANANOMALY_H___
#define ___MEANANOMALY_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> MeanAnomaly(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP,SEXP);


#endif  
